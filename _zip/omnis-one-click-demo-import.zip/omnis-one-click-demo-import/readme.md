## Omnis One Click Demo Import
One click demo importer for Omnis Theme.

Official [GitHub repository](https://github.com/proteusthemes/one-click-demo-import) of this plugin.